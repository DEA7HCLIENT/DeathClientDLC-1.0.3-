package dev.deathclient.dlc;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Line-only world drawing (boxes, segments) for the particle-free visuals.
 * Registered once from the client entrypoint; each visual module supplies its own draw calls.
 */
final class WorldRender {
    private WorldRender() {}

    static void init() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> {
            drawModule(ctx, ModuleManager.get(TargetEspModule2.class));
            drawModule(ctx, ModuleManager.get(TracersModule.class));
            drawModule(ctx, ModuleManager.get(LineTrailsModule.class));
        });
    }

    private static void drawModule(WorldRenderContext ctx, Module m) {
        if (m != null && m.isEnabled() && m instanceof WorldDrawable w) w.draw(ctx);
    }

    interface WorldDrawable { void draw(WorldRenderContext ctx); }

    /** Camera-relative line vertex consumer, depth-tested off so lines show through walls. */
    static VertexConsumerProvider.Immediate begin() {
        RenderSystem.lineWidth(2.0f);
        return VertexConsumerProvider.immediate(Tessellator.getInstance().getBuffer());
    }

    static void line(MatrixStack ms, VertexConsumer vc, Vec3d camera, Vec3d from, Vec3d to, float r, float g, float b, float a) {
        Matrix4f mat = ms.peek().getPositionMatrix();
        float x1 = (float) (from.x - camera.x), y1 = (float) (from.y - camera.y), z1 = (float) (from.z - camera.z);
        float x2 = (float) (to.x - camera.x), y2 = (float) (to.y - camera.y), z2 = (float) (to.z - camera.z);
        float nx = x2 - x1, ny = y2 - y1, nz = z2 - z1;
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len < 1.0E-5f) len = 1;
        vc.vertex(mat, x1, y1, z1).color(r, g, b, a).normal(nx / len, ny / len, nz / len);
        vc.vertex(mat, x2, y2, z2).color(r, g, b, a).normal(nx / len, ny / len, nz / len);
    }

    /** 12 edges of an entity's bounding box, inflated slightly so it reads as an outline. */
    static void box(MatrixStack ms, VertexConsumer vc, Vec3d camera, Box b, float r, float g, float bl, float a) {
        double x0 = b.minX, y0 = b.minY, z0 = b.minZ, x1 = b.maxX, y1 = b.maxY, z1 = b.maxZ;
        double[][] pts = {
                {x0,y0,z0},{x1,y0,z0},{x1,y0,z1},{x0,y0,z1},
                {x0,y1,z0},{x1,y1,z0},{x1,y1,z1},{x0,y1,z1}
        };
        int[][] edges = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
        for (int[] e : edges) {
            Vec3d from = new Vec3d(pts[e[0]][0], pts[e[0]][1], pts[e[0]][2]);
            Vec3d to = new Vec3d(pts[e[1]][0], pts[e[1]][1], pts[e[1]][2]);
            line(ms, vc, camera, from, to, r, g, bl, a);
        }
    }

    static Vec3d entityCamera(WorldRenderContext ctx) { return ctx.camera().getPos(); }
}
