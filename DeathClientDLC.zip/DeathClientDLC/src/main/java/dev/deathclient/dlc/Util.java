package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.util.math.Vec3d;

final class Util {
    private Util() {}

    static Vec3d pos(Entity e) { return new Vec3d(e.getX(), e.getY(), e.getZ()); }

    /** Normalized horizontal movement direction from WASD and yaw; zero vector if no input. */
    static Vec3d inputDir(MinecraftClient c, ClientPlayerEntity p) {
        GameOptions o = c.options;
        int f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        int s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) return Vec3d.ZERO;
        double yaw = Math.toRadians(p.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double x = -sin * f + cos * s;
        double z = cos * f + sin * s;
        double len = Math.sqrt(x * x + z * z);
        return new Vec3d(x / len, 0, z / len);
    }

    static PlayerEntity nearestPlayer(MinecraftClient c, double range) {
        PlayerEntity best = null;
        double bestD = range;
        for (PlayerEntity other : c.world.getPlayers()) {
            if (other == c.player || !other.isAlive() || other.isSpectator()) continue;
            double d = c.player.distanceTo(other);
            if (d <= bestD) { bestD = d; best = other; }
        }
        return best;
    }

    /** Hotbar slot (0-8) holding the item, or -1. */
    static int findHotbar(PlayerEntity p, Item item) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(item)) return i;
        return -1;
    }
}
