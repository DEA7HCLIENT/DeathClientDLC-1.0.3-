package dev.deathclient.dlc;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Box outline around the nearest target (line renderer, no particles). */
public class TargetEspModule2 extends Module implements WorldRender.WorldDrawable {
    public final NumberSetting range = add(new NumberSetting("Range", 8, 3, 20, 1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));

    public TargetEspModule2() { super("ESP", Category.VISUALS); }

    @Override
    public void draw(WorldRenderContext ctx) {
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) return;
        LivingEntity target = null;
        double best = range.get();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            double d = p.distanceTo(le);
            if (d <= best) { best = d; target = le; }
        }
        if (target == null) return;

        VertexConsumerProvider.Immediate buf = WorldRender.begin();
        var vc = buf.getBuffer(net.minecraft.client.render.RenderLayer.getLines());
        WorldRender.box(ctx.matrixStack(), vc, WorldRender.entityCamera(ctx),
                target.getBoundingBox().expand(0.05), 1.0f, 0.2f, 0.25f, 1.0f);
        buf.draw();
    }

    @Override
    public void onTick(MinecraftClient c) { /* drawing only, no tick logic */ }
}
