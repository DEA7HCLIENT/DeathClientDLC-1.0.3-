package dev.deathclient.dlc;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayDeque;
import java.util.Deque;

/** Line trail behind the player, built from recent positions (no particles). */
public class LineTrailsModule extends Module implements WorldRender.WorldDrawable {
    public final NumberSetting length = add(new NumberSetting("Length", 40, 10, 100, 5));

    private final Deque<Vec3d> history = new ArrayDeque<>();

    public LineTrailsModule() { super("Line Trails", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.player == null) return;
        history.addFirst(Util.pos(c.player).add(0, 0.1, 0));
        while (history.size() > (int) length.get()) history.removeLast();
    }

    @Override
    protected void onDisable() { history.clear(); }

    @Override
    public void draw(WorldRenderContext ctx) {
        if (history.size() < 2) return;
        VertexConsumerProvider.Immediate buf = WorldRender.begin();
        var vc = buf.getBuffer(RenderLayer.getLines());
        var camera = WorldRender.entityCamera(ctx);
        Vec3d prev = null;
        int i = 0, n = history.size();
        for (Vec3d v : history) {
            if (prev != null) {
                float a = 1.0f - (float) i / n;
                WorldRender.line(ctx.matrixStack(), vc, camera, prev, v, 0.7f, 0.1f, 0.15f, a);
            }
            prev = v;
            i++;
        }
        buf.draw();
    }
}
