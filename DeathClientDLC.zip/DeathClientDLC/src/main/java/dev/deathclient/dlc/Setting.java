package dev.deathclient.dlc;

public abstract class Setting {
    public final String name;
    protected Setting(String name) { this.name = name; }
}
