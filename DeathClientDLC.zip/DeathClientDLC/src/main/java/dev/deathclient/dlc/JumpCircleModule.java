package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** Expanding ring of particles at your feet when you jump. */
public class JumpCircleModule extends Module {
    private static final int GROW_TICKS = 6;

    public final NumberSetting style = add(Fx.styleSetting());
    public final NumberSetting radius = add(new NumberSetting("Radius", 1.5, 0.5, 4.0, 0.1));
    public final NumberSetting points = add(new NumberSetting("Points", 24, 12, 48, 4));

    private boolean wasOnGround;
    private int tick = -1;
    private double cx, cy, cz;

    public JumpCircleModule() { super("Jump Circle", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        boolean onGround = p.isOnGround();
        if (wasOnGround && !onGround && p.getVelocity().y > 0.1) {
            tick = 0;
            cx = p.getX();
            cy = p.getY() + 0.05;
            cz = p.getZ();
        }
        wasOnGround = onGround;

        if (tick >= 0) {
            double r = radius.get() * (tick + 1) / GROW_TICKS;
            Fx.ring(c, Fx.style(style), cx, cy, cz, r, (int) points.get());
            if (++tick >= GROW_TICKS) tick = -1;
        }
    }
}
