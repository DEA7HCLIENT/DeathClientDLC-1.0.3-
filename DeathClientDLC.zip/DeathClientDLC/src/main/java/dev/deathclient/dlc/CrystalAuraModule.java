package dev.deathclient.dlc;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Breaks End Crystals near the nearest player and places new ones on obsidian/bedrock next to them.
 * No damage calculation: it only avoids crystals closer than MIN_SELF_DIST to you.
 */
public class CrystalAuraModule extends Module {
    private static final double MIN_SELF_DIST = 3.0;

    public final NumberSetting targetRange = add(new NumberSetting("Target range", 12, 4, 20, 1));
    public final NumberSetting placeRange = add(new NumberSetting("Place range", 4.5, 2, 6, 0.5));
    public final NumberSetting breakRange = add(new NumberSetting("Break range", 4.5, 2, 6, 0.5));
    public final NumberSetting delay = add(new NumberSetting("Delay", 2, 1, 10, 1));
    public final BoolSetting place = add(new BoolSetting("Place", true));
    public final BoolSetting breakCrystals = add(new BoolSetting("Break", true));

    private int ticks;

    public CrystalAuraModule() { super("Crystal Aura", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        if (++ticks < (int) delay.get()) return;
        ticks = 0;
        ClientPlayerEntity p = c.player;
        PlayerEntity target = Util.nearestPlayer(c, targetRange.get());
        if (target == null) return;

        if (breakCrystals.get()) {
            for (Entity e : c.world.getEntities()) {
                if (!(e instanceof EndCrystalEntity)) continue;
                double d = p.distanceTo(e);
                if (d <= breakRange.get() && d >= MIN_SELF_DIST && e.distanceTo(target) <= 6.0) {
                    c.interactionManager.attackEntity(p, e);
                    p.swingHand(Hand.MAIN_HAND);
                    return;
                }
            }
        }
        if (place.get()) placeCrystal(c, p, target);
    }

    private void placeCrystal(MinecraftClient c, ClientPlayerEntity p, PlayerEntity target) {
        BlockPos tp = target.getBlockPos();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int x = -3; x <= 3; x++) for (int y = -3; y <= 1; y++) for (int z = -3; z <= 3; z++) {
            BlockPos b = tp.add(x, y, z);
            if (!(c.world.getBlockState(b).isOf(Blocks.OBSIDIAN) || c.world.getBlockState(b).isOf(Blocks.BEDROCK))) continue;
            if (!c.world.getBlockState(b.up()).isAir() || !c.world.getBlockState(b.up(2)).isAir()) continue;
            if (p.getEyePos().distanceTo(Vec3d.ofCenter(b)) > placeRange.get()) continue;
            Vec3d crystal = new Vec3d(b.getX() + 0.5, b.getY() + 1, b.getZ() + 0.5);
            if (Util.pos(p).distanceTo(crystal) < MIN_SELF_DIST) continue;
            Box space = new Box(b.getX(), b.getY() + 1, b.getZ(), b.getX() + 1, b.getY() + 3, b.getZ() + 1);
            if (!c.world.getOtherEntities(null, space).isEmpty()) continue;
            double d = crystal.distanceTo(Util.pos(target));
            if (d < bestD) { bestD = d; best = b; }
        }
        if (best == null) return;

        Hand hand;
        if (p.getOffHandStack().isOf(Items.END_CRYSTAL)) {
            hand = Hand.OFF_HAND;
        } else {
            if (!p.getMainHandStack().isOf(Items.END_CRYSTAL)) {
                int slot = Util.findHotbar(p, Items.END_CRYSTAL);
                if (slot < 0) return;
                p.getInventory().setSelectedSlot(slot);
            }
            hand = Hand.MAIN_HAND;
        }
        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(best).add(0, 0.5, 0), Direction.UP, best, false);
        c.interactionManager.interactBlock(p, hand, hit);
        p.swingHand(hand);
    }
}
